	<div class="footer">
		Copyright &copy; Павел Сериков, <?php echo date("Y");?>
	</div>
