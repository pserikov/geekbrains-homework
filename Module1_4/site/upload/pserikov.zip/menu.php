<div class="header">
	<a href="index.php">Главная</a>
	<a href="puzzle.php">Загадки</a>
	<a href="guess.php">Угадай число</a>
	<a href="pass.php">Генератор паролей</a>
	<a href="upload/pserikov.zip">Скачать код сайта</a>
</div>
